from flask import Flask, request, jsonify
from flask_cors import CORS
import mysql.connector
import os
from urllib.parse import urlparse
import time
from datetime import datetime, date, timedelta
from functools import wraps
import jwt
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
CORS(app, supports_credentials=True)

# Clé secrète pour JWT (en production, utiliser une variable d'environnement)
SECRET_KEY = os.environ.get('SECRET_KEY', 'gifi-stock-secret-key-2024')


def get_db_connection():
    """Établit une connexion à la base de données MySQL"""
    db_url = os.environ.get('DATABASE_URL')
    if not db_url:
        raise ValueError("DATABASE_URL n'est pas défini")

    parsed = urlparse(db_url)
    database = (parsed.path or '').lstrip('/')
    if not database:
        raise ValueError("DATABASE_URL doit contenir le nom de la base")

    return mysql.connector.connect(
        host=parsed.hostname or 'localhost',
        port=parsed.port or 3306,
        user=parsed.username,
        password=parsed.password,
        database=database,
        charset='utf8mb4',
        autocommit=False,
        use_pure=True
    )


def parse_bool(value, default=None):
    if isinstance(value, bool):
        return value
    if value is None:
        return default

    normalized = str(value).strip().lower()
    if normalized in {'1', 'true', 'yes', 'oui'}:
        return True
    if normalized in {'0', 'false', 'no', 'non'}:
        return False
    return default


def parse_int_value(value, default=0):
    if value in (None, ''):
        return default, None
    try:
        return int(value), None
    except (TypeError, ValueError):
        return None, 'La valeur doit être un entier'


def normalize_text(value):
    if value is None:
        return None
    return str(value).strip()


def normalize_date(value):
    cleaned = normalize_text(value)
    return cleaned if cleaned else None


def serialize_row(row):
    item = {}
    for key, value in dict(row).items():
        if isinstance(value, (datetime, date)):
            item[key] = value.isoformat()
        elif key == 'gere_au_serial_number' and value is not None:
            item[key] = bool(value)
        else:
            item[key] = value
    return item


def ensure_schema():
    """Crée les tables manquantes et applique les évolutions nécessaires"""
    conn = get_db_connection()
    cur = conn.cursor()

    # Tables coeur
    cur.execute(
        '''CREATE TABLE IF NOT EXISTS users (
               id INT AUTO_INCREMENT PRIMARY KEY,
               username VARCHAR(50) UNIQUE NOT NULL,
               password_hash VARCHAR(255) NOT NULL,
               role ENUM('admin', 'user') NOT NULL DEFAULT 'user',
               created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
           ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4'''
    )

    cur.execute(
        '''CREATE TABLE IF NOT EXISTS articles (
               id INT AUTO_INCREMENT PRIMARY KEY,
               name VARCHAR(255) UNIQUE NOT NULL,
               created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
               INDEX idx_articles_name (name)
           ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4'''
    )

    cur.execute(
        '''CREATE TABLE IF NOT EXISTS articles_consumables (
               id INT AUTO_INCREMENT PRIMARY KEY,
               name VARCHAR(255) UNIQUE NOT NULL,
               created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
               INDEX idx_articles_consumables_name (name)
           ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4'''
    )

    cur.execute(
        '''CREATE TABLE IF NOT EXISTS stock (
               id INT AUTO_INCREMENT PRIMARY KEY,
               sn VARCHAR(255) NOT NULL,
               article VARCHAR(255) NOT NULL,
               etat VARCHAR(100) NOT NULL,
               type_stock ENUM('input', 'output') NOT NULL,
               gere_au_serial_number TINYINT(1) NOT NULL DEFAULT 1,
               tag_integration CHAR(1) DEFAULT 'x',
               notes TEXT,
               ticket_bmc VARCHAR(255),
               nom_prenom VARCHAR(255),
               cause_installation_materiel TEXT,
               produits_installes TEXT,
               cause_recuperation_materiel TEXT,
               produits_recuperes TEXT,
               created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
               updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
               INDEX idx_stock_type (type_stock),
               INDEX idx_stock_tag (tag_integration),
               INDEX idx_stock_serial (gere_au_serial_number)
           ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4'''
    )

    # Migration pour les bases déjà existantes
    cur.execute(
        '''SELECT COUNT(*)
           FROM information_schema.columns
           WHERE table_schema = DATABASE()
             AND table_name = 'stock'
             AND column_name = 'gere_au_serial_number' '''
    )
    if cur.fetchone()[0] == 0:
        cur.execute(
            "ALTER TABLE stock ADD COLUMN gere_au_serial_number TINYINT(1) NOT NULL DEFAULT 1 AFTER type_stock"
        )

    cur.execute('SHOW INDEX FROM stock WHERE Key_name = %s', ('idx_stock_serial',))
    if cur.fetchone() is None:
        cur.execute('CREATE INDEX idx_stock_serial ON stock (gere_au_serial_number)')

    # Tables de consultation stock SN et consommable
    cur.execute(
        '''CREATE TABLE IF NOT EXISTS stock_sn (
               id INT AUTO_INCREMENT PRIMARY KEY,
               sn VARCHAR(255) NOT NULL,
               article VARCHAR(255) NOT NULL,
               attribution VARCHAR(255),
               neuf_occasion VARCHAR(60),
               etat VARCHAR(100),
               garantie VARCHAR(255),
               localisation VARCHAR(255),
               date_inventaire DATE,
               date_test_appareil DATE,
               notes TEXT,
               sortie_stock INT NOT NULL DEFAULT 0,
               entree_stock INT NOT NULL DEFAULT 0,
               created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
               updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
               INDEX idx_stock_sn_article (article),
               INDEX idx_stock_sn_sn (sn)
           ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4'''
    )

    cur.execute(
        '''CREATE TABLE IF NOT EXISTS stock_consumable (
               id INT AUTO_INCREMENT PRIMARY KEY,
               article VARCHAR(255) NOT NULL,
               attribution VARCHAR(255),
               neuf_occasion VARCHAR(60),
               etat VARCHAR(100),
               garantie VARCHAR(255),
               localisation VARCHAR(255),
               date_inventaire DATE,
               notes TEXT,
               sortie_stock INT NOT NULL DEFAULT 0,
               entree_stock INT NOT NULL DEFAULT 0,
               created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
               updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
               INDEX idx_stock_consumable_article (article)
           ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4'''
    )

    conn.commit()
    cur.close()
    conn.close()


def wait_for_integration_clear(conn, poll_interval=1):
    """Attend qu'aucune ligne n'ait tag_integration = 'w' avant d'écrire."""
    while True:
        cur = conn.cursor()
        cur.execute("SELECT 1 FROM stock WHERE tag_integration = 'w' LIMIT 1")
        has_lock = cur.fetchone() is not None
        cur.close()

        if not has_lock:
            return

        time.sleep(poll_interval)


def token_required(f):
    """Décorateur pour protéger les routes avec JWT"""
    @wraps(f)
    def decorated(*args, **kwargs):
        token = None

        if 'Authorization' in request.headers:
            auth_header = request.headers['Authorization']
            if auth_header.startswith('Bearer '):
                token = auth_header.split(' ')[1]

        if not token:
            return jsonify({'error': 'Token manquant'}), 401

        try:
            data = jwt.decode(token, SECRET_KEY, algorithms=['HS256'])
            conn = get_db_connection()
            cur = conn.cursor(dictionary=True)
            cur.execute('SELECT id, username, role FROM users WHERE id = %s', (data['user_id'],))
            current_user = cur.fetchone()
            cur.close()
            conn.close()

            if not current_user:
                return jsonify({'error': 'Utilisateur non trouvé'}), 401

        except jwt.ExpiredSignatureError:
            return jsonify({'error': 'Token expiré'}), 401
        except jwt.InvalidTokenError:
            return jsonify({'error': 'Token invalide'}), 401

        return f(current_user, *args, **kwargs)

    return decorated


def admin_required(f):
    """Décorateur pour les routes réservées aux administrateurs"""
    @wraps(f)
    def decorated(current_user, *args, **kwargs):
        if current_user['role'] != 'admin':
            return jsonify({'error': 'Accès réservé aux administrateurs'}), 403
        return f(current_user, *args, **kwargs)
    return decorated


def resolve_article_table(serial_managed):
    return 'articles' if serial_managed else 'articles_consumables'


# ==================== AUTHENTIFICATION ====================

@app.route('/api/auth/login', methods=['POST'])
def login():
    """Connexion utilisateur"""
    data = request.get_json()

    if not data or not data.get('username') or not data.get('password'):
        return jsonify({'error': 'Username et password requis'}), 400

    conn = get_db_connection()
    cur = conn.cursor(dictionary=True)

    cur.execute('SELECT * FROM users WHERE username = %s', (data['username'],))
    user = cur.fetchone()

    cur.close()
    conn.close()

    if not user or not check_password_hash(user['password_hash'], data['password']):
        return jsonify({'error': 'Identifiants incorrects'}), 401

    token = jwt.encode({
        'user_id': user['id'],
        'username': user['username'],
        'role': user['role'],
        'exp': datetime.utcnow() + timedelta(hours=24)
    }, SECRET_KEY, algorithm='HS256')

    return jsonify({
        'token': token,
        'user': {
            'id': user['id'],
            'username': user['username'],
            'role': user['role']
        }
    })


@app.route('/api/auth/me', methods=['GET'])
@token_required
def get_current_user(current_user):
    """Récupère les informations de l'utilisateur connecté"""
    return jsonify({
        'id': current_user['id'],
        'username': current_user['username'],
        'role': current_user['role']
    })


# ==================== GESTION DES UTILISATEURS (ADMIN) ====================

@app.route('/api/users', methods=['GET'])
@token_required
@admin_required
def get_users(current_user):
    """Récupère la liste des utilisateurs (admin uniquement)"""
    conn = get_db_connection()
    cur = conn.cursor(dictionary=True)

    cur.execute('SELECT id, username, role, created_at FROM users ORDER BY created_at DESC')
    users = cur.fetchall()

    cur.close()
    conn.close()

    return jsonify([serialize_row(user) for user in users])


@app.route('/api/users', methods=['POST'])
@token_required
@admin_required
def create_user(current_user):
    """Crée un nouvel utilisateur (admin uniquement)"""
    data = request.get_json() or {}

    if not data.get('username') or not data.get('password'):
        return jsonify({'error': 'Username et password requis'}), 400

    role = data.get('role', 'user')
    if role not in ['admin', 'user']:
        return jsonify({'error': 'Le rôle doit être "admin" ou "user"'}), 400

    conn = get_db_connection()
    cur = conn.cursor(dictionary=True)

    cur.execute('SELECT id FROM users WHERE username = %s', (data['username'],))
    if cur.fetchone():
        cur.close()
        conn.close()
        return jsonify({'error': 'Cet utilisateur existe déjà'}), 409

    password_hash = generate_password_hash(data['password'])

    wait_for_integration_clear(conn)

    cur.execute(
        '''INSERT INTO users (username, password_hash, role, created_at)
           VALUES (%s, %s, %s, CURRENT_TIMESTAMP)''',
        (data['username'], password_hash, role)
    )

    new_user_id = cur.lastrowid
    conn.commit()

    cur.execute('SELECT id, username, role, created_at FROM users WHERE id = %s', (new_user_id,))
    new_user = cur.fetchone()
    cur.close()
    conn.close()

    return jsonify(serialize_row(new_user)), 201


@app.route('/api/users/<int:user_id>', methods=['DELETE'])
@token_required
@admin_required
def delete_user(current_user, user_id):
    """Supprime un utilisateur (admin uniquement)"""
    if current_user['id'] == user_id:
        return jsonify({'error': 'Vous ne pouvez pas supprimer votre propre compte'}), 400

    conn = get_db_connection()
    cur = conn.cursor(dictionary=True)

    cur.execute('SELECT id FROM users WHERE id = %s', (user_id,))
    if not cur.fetchone():
        cur.close()
        conn.close()
        return jsonify({'error': 'Utilisateur non trouvé'}), 404

    wait_for_integration_clear(conn)
    cur.execute('DELETE FROM users WHERE id = %s', (user_id,))
    conn.commit()
    cur.close()
    conn.close()

    return jsonify({'message': 'Utilisateur supprimé avec succès'})


# ==================== ARTICLES ====================

@app.route('/api/articles', methods=['GET'])
@token_required
def list_articles(current_user):
    """Retourne la liste des articles disponibles selon le mode"""
    mode = normalize_text(request.args.get('mode')) or 'sn'
    mode = mode.lower()
    table_name = 'articles_consumables' if mode in {'consommable', 'consumable'} else 'articles'

    conn = get_db_connection()
    cur = conn.cursor(dictionary=True)
    cur.execute(f'SELECT id, name FROM {table_name} ORDER BY name ASC')
    rows = cur.fetchall()
    cur.close()
    conn.close()
    return jsonify([dict(r) for r in rows])


# ==================== SUIVI DES FORMULAIRES ====================

@app.route('/api/health', methods=['GET'])
def health_check():
    """Vérifie que l'API est opérationnelle"""
    return jsonify({'status': 'ok', 'message': 'API is running'})


@app.route('/api/stock', methods=['GET'])
@token_required
def get_all_stock(current_user):
    """Récupère les saisies de formulaires"""
    type_stock = request.args.get('type_stock')
    serial_managed_raw = request.args.get('serial_managed')

    clauses = []
    params = []

    if type_stock:
        if type_stock not in ['input', 'output']:
            return jsonify({'error': 'type_stock doit être "input" ou "output"'}), 400
        clauses.append('type_stock = %s')
        params.append(type_stock)

    if serial_managed_raw is not None:
        serial_managed = parse_bool(serial_managed_raw)
        if serial_managed is None:
            return jsonify({'error': 'serial_managed doit être true ou false'}), 400
        clauses.append('gere_au_serial_number = %s')
        params.append(1 if serial_managed else 0)

    query = 'SELECT * FROM stock'
    if clauses:
        query += ' WHERE ' + ' AND '.join(clauses)
    query += ' ORDER BY created_at DESC'

    conn = get_db_connection()
    cur = conn.cursor(dictionary=True)
    cur.execute(query, tuple(params))
    stocks = cur.fetchall()
    cur.close()
    conn.close()

    return jsonify([serialize_row(stock) for stock in stocks])


@app.route('/api/stock/<int:stock_id>', methods=['GET'])
@token_required
def get_stock(current_user, stock_id):
    """Récupère une saisie de formulaire par son ID"""
    conn = get_db_connection()
    cur = conn.cursor(dictionary=True)

    cur.execute('SELECT * FROM stock WHERE id = %s', (stock_id,))
    stock = cur.fetchone()

    cur.close()
    conn.close()

    if stock is None:
        return jsonify({'error': 'Stock non trouvé'}), 404

    return jsonify(serialize_row(stock))


@app.route('/api/stock', methods=['POST'])
@token_required
def create_stock(current_user):
    """Crée une nouvelle saisie de formulaire"""
    data = request.get_json() or {}

    article = normalize_text(data.get('article'))
    etat = normalize_text(data.get('etat'))
    type_stock = normalize_text(data.get('type_stock'))
    serial_managed = parse_bool(data.get('gere_au_serial_number'), default=True)

    if not article or not etat or not type_stock:
        return jsonify({'error': 'Les champs article, etat et type_stock sont requis'}), 400

    if type_stock not in ['input', 'output']:
        return jsonify({'error': 'type_stock doit être "input" ou "output"'}), 400

    sn = normalize_text(data.get('sn')) or ''
    if serial_managed and not sn:
        return jsonify({'error': 'Le champ sn est requis pour un article géré au numéro de série'}), 400

    notes = data.get('notes')
    ticket_bmc = data.get('ticket_bmc')
    nom_prenom = data.get('nom_prenom')
    cause_installation = data.get('cause_installation_materiel')
    produits_installes = data.get('produits_installes')
    cause_recuperation = data.get('cause_recuperation_materiel')
    produits_recuperes = data.get('produits_recuperes')

    conn = get_db_connection()
    cur = conn.cursor(dictionary=True)

    article_table = resolve_article_table(serial_managed)
    cur.execute(f'SELECT id FROM {article_table} WHERE name = %s', (article,))
    article_row = cur.fetchone()
    if not article_row:
        cur.close()
        conn.close()
        return jsonify({'error': "L'article n'existe pas dans la table attendue."}), 400

    wait_for_integration_clear(conn)
    cur.execute(
        '''INSERT INTO stock (
               sn, article, etat, type_stock, gere_au_serial_number, tag_integration,
               notes, ticket_bmc, nom_prenom,
               cause_installation_materiel, produits_installes,
               cause_recuperation_materiel, produits_recuperes,
               created_at, updated_at
           )
           VALUES (%s, %s, %s, %s, %s, 'x',
                   %s, %s, %s,
                   %s, %s,
                   %s, %s,
                   CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)''',
        (
            sn,
            article,
            etat,
            type_stock,
            1 if serial_managed else 0,
            notes,
            ticket_bmc,
            nom_prenom,
            cause_installation,
            produits_installes,
            cause_recuperation,
            produits_recuperes
        )
    )

    new_stock_id = cur.lastrowid
    conn.commit()

    cur.execute('SELECT * FROM stock WHERE id = %s', (new_stock_id,))
    new_stock = cur.fetchone()
    cur.close()
    conn.close()

    return jsonify(serialize_row(new_stock)), 201


@app.route('/api/stock/<int:stock_id>', methods=['PUT'])
@token_required
def update_stock(current_user, stock_id):
    """Met à jour une saisie de formulaire"""
    data = request.get_json() or {}

    conn = get_db_connection()
    cur = conn.cursor(dictionary=True)

    cur.execute('SELECT * FROM stock WHERE id = %s', (stock_id,))
    existing = cur.fetchone()

    if existing is None:
        cur.close()
        conn.close()
        return jsonify({'error': 'Stock non trouvé'}), 404

    serial_managed = bool(existing.get('gere_au_serial_number', 1))
    article = normalize_text(data.get('article', existing['article']))
    etat = normalize_text(data.get('etat', existing['etat']))

    if not article:
        cur.close()
        conn.close()
        return jsonify({'error': "L'article est requis"}), 400

    article_table = resolve_article_table(serial_managed)
    cur.execute(f'SELECT id FROM {article_table} WHERE name = %s', (article,))
    if not cur.fetchone():
        cur.close()
        conn.close()
        return jsonify({'error': "L'article n'existe pas dans la table attendue."}), 400

    notes = data.get('notes', existing.get('notes'))
    ticket_bmc = data.get('ticket_bmc', existing.get('ticket_bmc'))
    nom_prenom = data.get('nom_prenom', existing.get('nom_prenom'))

    if existing['type_stock'] == 'output':
        cause_installation = data.get('cause_installation_materiel', existing.get('cause_installation_materiel'))
        produits_installes = data.get('produits_installes', existing.get('produits_installes'))
        cause_recuperation = existing.get('cause_recuperation_materiel')
        produits_recuperes = existing.get('produits_recuperes')
    else:
        cause_installation = existing.get('cause_installation_materiel')
        produits_installes = existing.get('produits_installes')
        cause_recuperation = data.get('cause_recuperation_materiel', existing.get('cause_recuperation_materiel'))
        produits_recuperes = data.get('produits_recuperes', existing.get('produits_recuperes'))

    wait_for_integration_clear(conn)
    cur.execute(
        '''UPDATE stock
           SET article = %s,
               etat = %s,
               notes = %s,
               ticket_bmc = %s,
               nom_prenom = %s,
               cause_installation_materiel = %s,
               produits_installes = %s,
               cause_recuperation_materiel = %s,
               produits_recuperes = %s,
               tag_integration = 'x',
               updated_at = CURRENT_TIMESTAMP
           WHERE id = %s''',
        (
            article,
            etat,
            notes,
            ticket_bmc,
            nom_prenom,
            cause_installation,
            produits_installes,
            cause_recuperation,
            produits_recuperes,
            stock_id
        )
    )

    conn.commit()

    cur.execute('SELECT * FROM stock WHERE id = %s', (stock_id,))
    updated_stock = cur.fetchone()
    cur.close()
    conn.close()

    return jsonify(serialize_row(updated_stock))


@app.route('/api/stock/<int:stock_id>', methods=['DELETE'])
@token_required
def delete_stock(current_user, stock_id):
    """Supprime une saisie de formulaire (seulement si tag_integration = 'x')"""
    conn = get_db_connection()
    cur = conn.cursor(dictionary=True)

    cur.execute('SELECT * FROM stock WHERE id = %s', (stock_id,))
    existing = cur.fetchone()

    if existing is None:
        cur.close()
        conn.close()
        return jsonify({'error': 'Stock non trouvé'}), 404

    if existing['tag_integration'] != 'x':
        cur.close()
        conn.close()
        return jsonify({'error': 'Cette donnée est déjà intégrée et ne peut pas être supprimée'}), 403

    wait_for_integration_clear(conn)
    cur.execute('DELETE FROM stock WHERE id = %s', (stock_id,))
    conn.commit()
    cur.close()
    conn.close()

    return jsonify({'message': 'Stock supprimé avec succès'}), 200


# ==================== STOCK SN (TABLEAU DE CONSULTATION) ====================

@app.route('/api/stock-sn', methods=['GET'])
@token_required
def list_stock_sn(current_user):
    q = normalize_text(request.args.get('q')) or ''
    sort_by = normalize_text(request.args.get('sort_by')) or 'updated_at'
    sort_order = (normalize_text(request.args.get('sort_order')) or 'desc').lower()

    sortable_columns = {
        'sn', 'article', 'attribution', 'neuf_occasion', 'etat', 'garantie',
        'localisation', 'date_inventaire', 'date_test_appareil',
        'sortie_stock', 'entree_stock', 'created_at', 'updated_at'
    }
    if sort_by not in sortable_columns:
        sort_by = 'updated_at'
    if sort_order not in {'asc', 'desc'}:
        sort_order = 'desc'

    query = 'SELECT * FROM stock_sn'
    params = []
    if q:
        like_value = f'%{q}%'
        query += (
            ' WHERE sn LIKE %s OR article LIKE %s OR attribution LIKE %s OR '
            'neuf_occasion LIKE %s OR etat LIKE %s OR garantie LIKE %s OR '
            'localisation LIKE %s OR notes LIKE %s'
        )
        params = [like_value] * 8

    query += f' ORDER BY {sort_by} {sort_order.upper()}, id DESC'

    conn = get_db_connection()
    cur = conn.cursor(dictionary=True)
    cur.execute(query, tuple(params))
    rows = cur.fetchall()
    cur.close()
    conn.close()

    return jsonify([serialize_row(row) for row in rows])


@app.route('/api/stock-sn', methods=['POST'])
@token_required
@admin_required
def create_stock_sn(current_user):
    data = request.get_json() or {}

    sn = normalize_text(data.get('sn'))
    article = normalize_text(data.get('article'))
    if not sn or not article:
        return jsonify({'error': 'Les champs S/N et Article sont requis'}), 400

    sortie_stock, sortie_error = parse_int_value(data.get('sortie_stock'), default=0)
    entree_stock, entree_error = parse_int_value(data.get('entree_stock'), default=0)
    if sortie_error or entree_error:
        return jsonify({'error': 'sortie_stock et entree_stock doivent être des entiers'}), 400

    payload = (
        sn,
        article,
        normalize_text(data.get('attribution')),
        normalize_text(data.get('neuf_occasion')),
        normalize_text(data.get('etat')),
        normalize_text(data.get('garantie')),
        normalize_text(data.get('localisation')),
        normalize_date(data.get('date_inventaire')),
        normalize_date(data.get('date_test_appareil')),
        data.get('notes'),
        sortie_stock,
        entree_stock
    )

    conn = get_db_connection()
    cur = conn.cursor(dictionary=True)

    wait_for_integration_clear(conn)
    cur.execute(
        '''INSERT INTO stock_sn (
               sn, article, attribution, neuf_occasion, etat, garantie,
               localisation, date_inventaire, date_test_appareil,
               notes, sortie_stock, entree_stock,
               created_at, updated_at
           )
           VALUES (%s, %s, %s, %s, %s, %s,
                   %s, %s, %s,
                   %s, %s, %s,
                   CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)''',
        payload
    )

    row_id = cur.lastrowid
    conn.commit()

    cur.execute('SELECT * FROM stock_sn WHERE id = %s', (row_id,))
    row = cur.fetchone()
    cur.close()
    conn.close()

    return jsonify(serialize_row(row)), 201


@app.route('/api/stock-sn/<int:row_id>', methods=['GET'])
@token_required
def get_stock_sn_row(current_user, row_id):
    conn = get_db_connection()
    cur = conn.cursor(dictionary=True)
    cur.execute('SELECT * FROM stock_sn WHERE id = %s', (row_id,))
    row = cur.fetchone()
    cur.close()
    conn.close()

    if row is None:
        return jsonify({'error': 'Ligne non trouvée'}), 404

    return jsonify(serialize_row(row))


@app.route('/api/stock-sn/<int:row_id>', methods=['PUT'])
@token_required
@admin_required
def update_stock_sn(current_user, row_id):
    data = request.get_json() or {}

    conn = get_db_connection()
    cur = conn.cursor(dictionary=True)

    cur.execute('SELECT * FROM stock_sn WHERE id = %s', (row_id,))
    existing = cur.fetchone()
    if existing is None:
        cur.close()
        conn.close()
        return jsonify({'error': 'Ligne non trouvée'}), 404

    sn = normalize_text(data.get('sn', existing['sn']))
    article = normalize_text(data.get('article', existing['article']))
    if not sn or not article:
        cur.close()
        conn.close()
        return jsonify({'error': 'Les champs S/N et Article sont requis'}), 400

    sortie_stock, sortie_error = parse_int_value(data.get('sortie_stock', existing['sortie_stock']), default=0)
    entree_stock, entree_error = parse_int_value(data.get('entree_stock', existing['entree_stock']), default=0)
    if sortie_error or entree_error:
        cur.close()
        conn.close()
        return jsonify({'error': 'sortie_stock et entree_stock doivent être des entiers'}), 400

    wait_for_integration_clear(conn)
    cur.execute(
        '''UPDATE stock_sn
           SET sn = %s,
               article = %s,
               attribution = %s,
               neuf_occasion = %s,
               etat = %s,
               garantie = %s,
               localisation = %s,
               date_inventaire = %s,
               date_test_appareil = %s,
               notes = %s,
               sortie_stock = %s,
               entree_stock = %s,
               updated_at = CURRENT_TIMESTAMP
           WHERE id = %s''',
        (
            sn,
            article,
            normalize_text(data.get('attribution', existing.get('attribution'))),
            normalize_text(data.get('neuf_occasion', existing.get('neuf_occasion'))),
            normalize_text(data.get('etat', existing.get('etat'))),
            normalize_text(data.get('garantie', existing.get('garantie'))),
            normalize_text(data.get('localisation', existing.get('localisation'))),
            normalize_date(data.get('date_inventaire', existing.get('date_inventaire'))),
            normalize_date(data.get('date_test_appareil', existing.get('date_test_appareil'))),
            data.get('notes', existing.get('notes')),
            sortie_stock,
            entree_stock,
            row_id
        )
    )

    conn.commit()

    cur.execute('SELECT * FROM stock_sn WHERE id = %s', (row_id,))
    updated = cur.fetchone()
    cur.close()
    conn.close()

    return jsonify(serialize_row(updated))


@app.route('/api/stock-sn/<int:row_id>', methods=['DELETE'])
@token_required
@admin_required
def delete_stock_sn(current_user, row_id):
    conn = get_db_connection()
    cur = conn.cursor(dictionary=True)

    cur.execute('SELECT id FROM stock_sn WHERE id = %s', (row_id,))
    if not cur.fetchone():
        cur.close()
        conn.close()
        return jsonify({'error': 'Ligne non trouvée'}), 404

    wait_for_integration_clear(conn)
    cur.execute('DELETE FROM stock_sn WHERE id = %s', (row_id,))
    conn.commit()
    cur.close()
    conn.close()

    return jsonify({'message': 'Ligne supprimée avec succès'})


# ==================== STOCK CONSOMMABLE (TABLEAU DE CONSULTATION) ====================

@app.route('/api/stock-consommable', methods=['GET'])
@token_required
def list_stock_consumable(current_user):
    q = normalize_text(request.args.get('q')) or ''
    sort_by = normalize_text(request.args.get('sort_by')) or 'updated_at'
    sort_order = (normalize_text(request.args.get('sort_order')) or 'desc').lower()

    sortable_columns = {
        'id', 'article', 'attribution', 'neuf_occasion', 'etat', 'garantie',
        'localisation', 'date_inventaire', 'sortie_stock', 'entree_stock',
        'created_at', 'updated_at'
    }
    if sort_by not in sortable_columns:
        sort_by = 'updated_at'
    if sort_order not in {'asc', 'desc'}:
        sort_order = 'desc'

    query = 'SELECT * FROM stock_consumable'
    params = []
    if q:
        like_value = f'%{q}%'
        query += (
            ' WHERE article LIKE %s OR attribution LIKE %s OR '
            'neuf_occasion LIKE %s OR etat LIKE %s OR garantie LIKE %s OR '
            'localisation LIKE %s OR notes LIKE %s'
        )
        params = [like_value] * 7

    query += f' ORDER BY {sort_by} {sort_order.upper()}, id DESC'

    conn = get_db_connection()
    cur = conn.cursor(dictionary=True)
    cur.execute(query, tuple(params))
    rows = cur.fetchall()
    cur.close()
    conn.close()

    return jsonify([serialize_row(row) for row in rows])


@app.route('/api/stock-consommable', methods=['POST'])
@token_required
@admin_required
def create_stock_consumable(current_user):
    data = request.get_json() or {}

    article = normalize_text(data.get('article'))
    if not article:
        return jsonify({'error': 'Le champ Article est requis'}), 400

    sortie_stock, sortie_error = parse_int_value(data.get('sortie_stock'), default=0)
    entree_stock, entree_error = parse_int_value(data.get('entree_stock'), default=0)
    if sortie_error or entree_error:
        return jsonify({'error': 'sortie_stock et entree_stock doivent être des entiers'}), 400

    payload = (
        article,
        normalize_text(data.get('attribution')),
        normalize_text(data.get('neuf_occasion')),
        normalize_text(data.get('etat')),
        normalize_text(data.get('garantie')),
        normalize_text(data.get('localisation')),
        normalize_date(data.get('date_inventaire')),
        data.get('notes'),
        sortie_stock,
        entree_stock
    )

    conn = get_db_connection()
    cur = conn.cursor(dictionary=True)

    wait_for_integration_clear(conn)
    cur.execute(
        '''INSERT INTO stock_consumable (
               article, attribution, neuf_occasion, etat, garantie,
               localisation, date_inventaire, notes,
               sortie_stock, entree_stock,
               created_at, updated_at
           )
           VALUES (%s, %s, %s, %s, %s,
                   %s, %s, %s,
                   %s, %s,
                   CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)''',
        payload
    )

    row_id = cur.lastrowid
    conn.commit()

    cur.execute('SELECT * FROM stock_consumable WHERE id = %s', (row_id,))
    row = cur.fetchone()
    cur.close()
    conn.close()

    return jsonify(serialize_row(row)), 201


@app.route('/api/stock-consommable/<int:row_id>', methods=['GET'])
@token_required
def get_stock_consumable_row(current_user, row_id):
    conn = get_db_connection()
    cur = conn.cursor(dictionary=True)
    cur.execute('SELECT * FROM stock_consumable WHERE id = %s', (row_id,))
    row = cur.fetchone()
    cur.close()
    conn.close()

    if row is None:
        return jsonify({'error': 'Ligne non trouvée'}), 404

    return jsonify(serialize_row(row))


@app.route('/api/stock-consommable/<int:row_id>', methods=['PUT'])
@token_required
@admin_required
def update_stock_consumable(current_user, row_id):
    data = request.get_json() or {}

    conn = get_db_connection()
    cur = conn.cursor(dictionary=True)

    cur.execute('SELECT * FROM stock_consumable WHERE id = %s', (row_id,))
    existing = cur.fetchone()
    if existing is None:
        cur.close()
        conn.close()
        return jsonify({'error': 'Ligne non trouvée'}), 404

    article = normalize_text(data.get('article', existing['article']))
    if not article:
        cur.close()
        conn.close()
        return jsonify({'error': 'Le champ Article est requis'}), 400

    sortie_stock, sortie_error = parse_int_value(data.get('sortie_stock', existing['sortie_stock']), default=0)
    entree_stock, entree_error = parse_int_value(data.get('entree_stock', existing['entree_stock']), default=0)
    if sortie_error or entree_error:
        cur.close()
        conn.close()
        return jsonify({'error': 'sortie_stock et entree_stock doivent être des entiers'}), 400

    wait_for_integration_clear(conn)
    cur.execute(
        '''UPDATE stock_consumable
           SET article = %s,
               attribution = %s,
               neuf_occasion = %s,
               etat = %s,
               garantie = %s,
               localisation = %s,
               date_inventaire = %s,
               notes = %s,
               sortie_stock = %s,
               entree_stock = %s,
               updated_at = CURRENT_TIMESTAMP
           WHERE id = %s''',
        (
            article,
            normalize_text(data.get('attribution', existing.get('attribution'))),
            normalize_text(data.get('neuf_occasion', existing.get('neuf_occasion'))),
            normalize_text(data.get('etat', existing.get('etat'))),
            normalize_text(data.get('garantie', existing.get('garantie'))),
            normalize_text(data.get('localisation', existing.get('localisation'))),
            normalize_date(data.get('date_inventaire', existing.get('date_inventaire'))),
            data.get('notes', existing.get('notes')),
            sortie_stock,
            entree_stock,
            row_id
        )
    )

    conn.commit()

    cur.execute('SELECT * FROM stock_consumable WHERE id = %s', (row_id,))
    updated = cur.fetchone()
    cur.close()
    conn.close()

    return jsonify(serialize_row(updated))


@app.route('/api/stock-consommable/<int:row_id>', methods=['DELETE'])
@token_required
@admin_required
def delete_stock_consumable(current_user, row_id):
    conn = get_db_connection()
    cur = conn.cursor(dictionary=True)

    cur.execute('SELECT id FROM stock_consumable WHERE id = %s', (row_id,))
    if not cur.fetchone():
        cur.close()
        conn.close()
        return jsonify({'error': 'Ligne non trouvée'}), 404

    wait_for_integration_clear(conn)
    cur.execute('DELETE FROM stock_consumable WHERE id = %s', (row_id,))
    conn.commit()
    cur.close()
    conn.close()

    return jsonify({'message': 'Ligne supprimée avec succès'})


def init_admin_user():
    """Crée l'utilisateur admin par défaut s'il n'existe pas"""
    try:
        conn = get_db_connection()
        cur = conn.cursor(dictionary=True)

        cur.execute('SELECT id FROM users WHERE username = %s', ('admin',))
        if not cur.fetchone():
            password_hash = generate_password_hash('admin123')
            wait_for_integration_clear(conn)
            cur.execute(
                '''INSERT INTO users (username, password_hash, role, created_at)
                   VALUES (%s, %s, %s, CURRENT_TIMESTAMP)''',
                ('admin', password_hash, 'admin')
            )
            conn.commit()
            print('✅ Utilisateur admin créé avec succès (mot de passe: admin123)')
        else:
            print('ℹ️ Utilisateur admin déjà existant')

        cur.close()
        conn.close()
    except Exception as e:
        print(f'⚠️ Erreur lors de la création de l\'admin: {e}')


def bootstrap_schema():
    try:
        ensure_schema()
    except Exception as e:
        print(f'⚠️ Erreur lors de la migration du schéma: {e}')


# Initialiser le schéma et l'admin lors du chargement du module (utile avec gunicorn)
bootstrap_schema()
init_admin_user()


if __name__ == '__main__':
    # Initialiser au démarrage en mode debug local
    time.sleep(2)  # Attendre que la base de données soit prête
    bootstrap_schema()
    init_admin_user()
    app.run(host='0.0.0.0', port=5000, debug=True)
