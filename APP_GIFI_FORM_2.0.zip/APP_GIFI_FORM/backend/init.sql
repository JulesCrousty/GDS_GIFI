-- Création de la table users
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('admin', 'user') NOT NULL DEFAULT 'user',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table des articles gérés au numéro de série
CREATE TABLE IF NOT EXISTS articles (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) UNIQUE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_articles_name (name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table des articles consommables
CREATE TABLE IF NOT EXISTS articles_consumables (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) UNIQUE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_articles_consumables_name (name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table des saisies formulaires (entrée/sortie)
CREATE TABLE IF NOT EXISTS stock (
    id INT AUTO_INCREMENT PRIMARY KEY,
    sn VARCHAR(255) NOT NULL,
    article VARCHAR(255) NOT NULL,
    etat VARCHAR(100) NOT NULL,
    type_stock ENUM('input', 'output') NOT NULL,
    gere_au_serial_number TINYINT(1) NOT NULL DEFAULT 1,
    tag_integration CHAR(1) DEFAULT 'x',
    notes TEXT,
    ticket_bmc VARCHAR(255),
    nom_prenom VARCHAR(255),
    cause_installation_materiel TEXT,
    produits_installes TEXT,
    cause_recuperation_materiel TEXT,
    produits_recuperes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_stock_type (type_stock),
    INDEX idx_stock_tag (tag_integration),
    INDEX idx_stock_serial (gere_au_serial_number)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table de consultation du stock S/N
CREATE TABLE IF NOT EXISTS stock_sn (
    id INT AUTO_INCREMENT PRIMARY KEY,
    sn VARCHAR(255) NOT NULL,
    article VARCHAR(255) NOT NULL,
    attribution VARCHAR(255),
    neuf_occasion VARCHAR(60),
    etat VARCHAR(100),
    garantie VARCHAR(255),
    localisation VARCHAR(255),
    date_inventaire DATE,
    date_test_appareil DATE,
    notes TEXT,
    sortie_stock INT NOT NULL DEFAULT 0,
    entree_stock INT NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_stock_sn_article (article),
    INDEX idx_stock_sn_sn (sn)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table de consultation du stock consommable
CREATE TABLE IF NOT EXISTS stock_consumable (
    id INT AUTO_INCREMENT PRIMARY KEY,
    article VARCHAR(255) NOT NULL,
    attribution VARCHAR(255),
    neuf_occasion VARCHAR(60),
    etat VARCHAR(100),
    garantie VARCHAR(255),
    localisation VARCHAR(255),
    date_inventaire DATE,
    notes TEXT,
    sortie_stock INT NOT NULL DEFAULT 0,
    entree_stock INT NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_stock_consumable_article (article)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
