(() => {
  function closeAllSingleSelects(except) {
    document.querySelectorAll('.single-select.open').forEach((el) => {
      if (el !== except) {
        el.classList.remove('open');
      }
    });
  }

  function mountSingleSelect(select) {
    if (!(select instanceof HTMLSelectElement) || select.dataset.singleSelectInit === 'true') {
      return;
    }

    const wrapper = document.createElement('div');
    wrapper.className = 'single-select';

    const toggle = document.createElement('button');
    toggle.type = 'button';
    toggle.className = 'single-select-toggle';
    toggle.setAttribute('aria-haspopup', 'listbox');

    const options = document.createElement('div');
    options.className = 'options';
    options.setAttribute('role', 'listbox');

    wrapper.append(toggle, options);
    select.insertAdjacentElement('afterend', wrapper);
    select.classList.add('single-select-native');
    select.dataset.singleSelectInit = 'true';

    const rows = [];

    Array.from(select.options).forEach((opt) => {
      const row = document.createElement('div');
      row.className = 'option-item';
      row.dataset.value = opt.value;
      row.textContent = opt.textContent;

      if (!opt.value) {
        row.classList.add('placeholder');
      }

      if (opt.disabled) {
        row.classList.add('disabled');
      } else {
        row.addEventListener('click', () => {
          select.value = opt.value;
          select.dispatchEvent(new Event('change', { bubbles: true }));
          closeAllSingleSelects();
          sync();
        });
      }

      rows.push(row);
      options.appendChild(row);
    });

    function sync() {
      const selectedIndex = select.selectedIndex >= 0 ? select.selectedIndex : 0;
      const selectedOption = select.options[selectedIndex];
      const selectedText = selectedOption ? selectedOption.textContent : 'Sélectionner';

      toggle.textContent = selectedText;
      toggle.disabled = !!select.disabled;
      wrapper.classList.toggle('is-empty', !select.value);

      rows.forEach((row) => {
        row.classList.toggle('selected', row.dataset.value === select.value);
      });
    }

    toggle.addEventListener('click', () => {
      if (toggle.disabled) {
        return;
      }

      const shouldOpen = !wrapper.classList.contains('open');
      closeAllSingleSelects(wrapper);
      wrapper.classList.toggle('open', shouldOpen);
    });

    select.addEventListener('change', sync);
    select.addEventListener('single-select:sync', sync);

    if (select.form) {
      select.form.addEventListener('reset', () => {
        setTimeout(sync, 0);
      });
    }

    sync();
  }

  function mountAllSingleSelects() {
    document.querySelectorAll('select').forEach((select) => {
      if (!select.dataset.singleSelectSkip) {
        mountSingleSelect(select);
      }
    });
  }

  document.addEventListener('click', (event) => {
    document.querySelectorAll('.single-select.open').forEach((el) => {
      if (!el.contains(event.target)) {
        el.classList.remove('open');
      }
    });
  });

  window.refreshSingleSelects = () => {
    document.querySelectorAll('select.single-select-native').forEach((select) => {
      select.dispatchEvent(new Event('single-select:sync'));
    });
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', mountAllSingleSelects);
  } else {
    mountAllSingleSelects();
  }
})();
