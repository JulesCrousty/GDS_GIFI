(() => {
  const STORAGE_KEY = 'gifi-theme';
  const root = document.documentElement;

  const getSystemTheme = () =>
    window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches
      ? 'dark'
      : 'light';

  const getStoredTheme = () => {
    const saved = localStorage.getItem(STORAGE_KEY);
    return saved === 'dark' || saved === 'light' ? saved : null;
  };

  const applyTheme = (theme) => {
    root.setAttribute('data-theme', theme);
    localStorage.setItem(STORAGE_KEY, theme);
    const label = document.querySelector('.theme-toggle-label');
    const icon = document.querySelector('.theme-toggle-icon');
    if (label && icon) {
      const dark = theme === 'dark';
      label.textContent = dark ? 'Mode clair' : 'Mode sombre';
      icon.textContent = dark ? 'DAY' : 'NIGHT';
    }
  };

  const initialTheme = getStoredTheme() || getSystemTheme();
  root.setAttribute('data-theme', initialTheme);

  const mountToggle = () => {
    if (!document.body || document.querySelector('.theme-toggle')) {
      return;
    }

    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'theme-toggle';
    button.setAttribute('aria-label', 'Basculer le thème clair/sombre');

    const icon = document.createElement('span');
    icon.className = 'theme-toggle-icon';

    const label = document.createElement('span');
    label.className = 'theme-toggle-label';

    button.append(icon, label);
    button.addEventListener('click', () => {
      const nextTheme = root.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
      applyTheme(nextTheme);
    });

    document.body.appendChild(button);
    applyTheme(root.getAttribute('data-theme') || initialTheme);
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', mountToggle);
  } else {
    mountToggle();
  }
})();
